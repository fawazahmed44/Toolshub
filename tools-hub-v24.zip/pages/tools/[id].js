import {page,esc} from 'lib/html.js';
export const access='public';
const tools={
'jpg-pdf':['Image to PDF','PDF','Convert JPG, JPEG, PNG and WebP images into a downloadable PDF online for free.'],
'pdf-merge':['PDF Merge','PDF','Merge multiple PDF files into one document directly in your browser.'],
'pdf-split':['PDF Page Extractor','PDF','Extract selected pages from a PDF and download the result in your browser.'],
'image-compressor':['Image Compressor','Image','Compress JPG, PNG and WebP images online while keeping processing in your browser.'],
'image-resizer':['Image Resizer','Image','Resize an image to exact dimensions online and download it instantly.'],
'image-converter':['Image Converter','Image','Convert images between PNG, JPEG and WebP formats in your browser.'],
'qr':['QR Code Generator','Generators','Create a downloadable QR code for text or links for free.'],
'word-counter':['Word Counter','Text','Count words, characters, sentences and paragraphs instantly.'],
'json-formatter':['JSON Formatter','Developer','Format, validate and minify JSON locally in your browser.'],
'base64':['Base64 Encoder / Decoder','Developer','Encode or decode Base64 text locally without uploading content.'],
'url-encoder':['URL Encoder / Decoder','Developer','Safely encode or decode URL components online.'],
'uuid':['UUID Generator','Developer','Generate cryptographically strong UUID v4 values in your browser.'],
'password-generator':['Password Generator','Security','Generate strong random passwords locally with no API key.'],
'percentage':['Percentage Calculator','Calculators','Calculate percentages, increases and decreases quickly.'],
'discount':['Discount Calculator','Calculators','Calculate sale prices, discounts and savings instantly.'],
'emi':['EMI Calculator','Calculators','Estimate monthly loan payments and total interest.'],
'age':['Age Calculator','Calculators','Calculate age in years, months and days from a birth date.'],
'tip':['Tip Calculator','Calculators','Calculate tip and split a bill.'],
'unit':['Unit Converter','Calculators','Convert length, weight, temperature and data units online.'],
'image-grayscale':['Image Grayscale','Image','Turn images into grayscale locally in your browser.'],
'pdf-rotate':['PDF Rotate','PDF','Rotate PDF pages and download the processed document in your browser.'],
'pdf-compress':['PDF Compressor','PDF','Reduce and re-save PDF documents in your browser where supported.'],
'color-hex-rgb':['HEX to RGB Converter','Design','Convert HEX colors to RGB values instantly.'],
'gradient-generator':['CSS Gradient Generator','Design','Generate copy-ready CSS linear gradients.'],
'bmi':['BMI Calculator','Calculators','Calculate body mass index from height and weight.'],
'percentage-change':['Percentage Change Calculator','Calculators','Calculate percentage increase or decrease between two values.'],
'compound-interest':['Compound Interest Calculator','Calculators','Calculate compound interest and future value.'],
'meta-title':['Meta Title Generator','SEO','Create an SEO-friendly meta title for a webpage.'],
'meta-description':['Meta Description Generator','SEO','Create a concise SEO-friendly meta description.'],
'robots':['Robots.txt Generator','SEO','Generate a simple robots.txt file for search engine crawlers.'],
'sitemap':['XML Sitemap Generator','SEO','Generate an XML sitemap from a list of URLs.'],
'schema':['Schema Markup Generator','SEO','Generate basic Schema.org structured data.']};
const knownCats={pdf:'PDF',image:'Image',text:'Text',developer:'Developer',security:'Security',calculators:'Calculators',seo:'SEO',design:'Design',business:'Business',files:'Files',generators:'Generators'};
const pretty=s=>s.split('-').map(x=>x.charAt(0).toUpperCase()+x.slice(1)).join(' ');
export default async function(req,res){
 const id=req.params.id;
 let t=tools[id];
 if(!t){
   const name=pretty(id), first=id.split('-')[0], cat=knownCats[first]||(['calculator','interest','percentage','bmi','ratio','date','pace','fuel'].some(x=>id.includes(x))?'Calculators':'Developer');
   t=[name,cat,`Free online ${name.toLowerCase()} for fast browser-based work. Use Tools Hub to process your input locally whenever practical.`];
 }
 const [name,cat,desc]=t,url='https://tools-hub.hatchable.site/tools/'+id;
 const schema=JSON.stringify({'@context':'https://schema.org','@type':'WebApplication',name,url,applicationCategory:'UtilitiesApplication',operatingSystem:'Web',description:desc,offers:{'@type':'Offer',price:'0',priceCurrency:'USD'}});
 const faq=JSON.stringify({'@context':'https://schema.org','@type':'FAQPage',mainEntity:[
  {'@type':'Question',name:`What is ${name}?`,acceptedAnswer:{'@type':'Answer',text:desc}},
  {'@type':'Question',name:`Is ${name} free?`,acceptedAnswer:{'@type':'Answer',text:`Yes. Tools Hub provides this browser-based utility for free.`}},
  {'@type':'Question',name:`Are my files uploaded?`,acceptedAnswer:{'@type':'Answer',text:'When the tool supports local browser processing, your input is processed on your device rather than permanently stored by Tools Hub.'}}
 ]});
 const related=Object.entries(tools).filter(([k,v])=>v[1]===cat&&k!==id).slice(0,6);
  const relatedHtml=related.length?'<section class="section"><div class="sectionhead"><h2>Related '+esc(cat)+' tools</h2><a class="btn" href="/tools">View all tools</a></div><div class="grid">'+related.map(([k,v])=>'<article class="card toolcard"><div class="toolicon">✦</div><h3>'+esc(v[0])+'</h3><p>'+esc(v[2])+'</p><div class="row" style="margin-top:12px"><a class="btn primary" href="/?tool='+encodeURIComponent(k)+'">Open tool</a></div></article>').join('')+'</div></section>':'<section class="section"><div class="card"><h2>Explore Tools Hub</h2><p class="muted">Discover more free browser tools.</p><a class="btn primary" href="/tools">Browse all tools</a></div></section>';
  const body='<script type="application/ld+json">'+schema+'</script><script type="application/ld+json">'+faq+'</script><header class="header"><nav class="nav"><a class="brand" href="/" style="color:inherit;text-decoration:none"><span class="logo">T</span>Tools Hub</a><div class="navlinks" style="margin-left:auto"><a href="/">Home</a><a href="/tools">All Tools</a></div><div class="header-actions"><a class="iconbtn" href="/tools" aria-label="All tools" style="display:grid;place-items:center;text-decoration:none;color:inherit">⌘</a><button class="iconbtn" onclick="document.documentElement.classList.toggle(\"dark\");localStorage.setItem(\"th_dark\",document.documentElement.classList.contains(\"dark\"))" aria-label="Toggle theme">◐</button></div></nav></header><main class="toolpage"><div class="crumb"><a href="/">Tools Hub</a> / <a href="/tools">All Tools</a> / '+esc(name)+'</div><div class="tooltitle"><div><span class="eyebrow">FREE '+esc(cat).toUpperCase()+' TOOL</span><h1>'+esc(name)+'</h1><p class="muted">'+esc(desc)+'</p></div></div><section class="workspace"><h2 style="margin-top:0">Ready to use '+esc(name)+'?</h2><p class="muted">Open the interactive tool below. Your browser handles supported processing locally.</p><a class="btn primary" href="/?tool='+encodeURIComponent(id)+'">Open '+esc(name)+'</a></section><section class="section"><div class="card"><h2>How to use '+esc(name)+'</h2><ol><li>Open the interactive tool.</li><li>Enter or select your information.</li><li>Run the tool, then copy or download the result.</li></ol><h2>Why use Tools Hub?</h2><p class="muted">Tools Hub brings free browser utilities for PDFs, images, text, developer tasks, calculations, SEO, security and more into one mobile-friendly website. No signup or user API key is required for core utilities.</p><h2>Privacy</h2><p class="muted">Whenever practical, processing happens locally in your browser. Do not upload sensitive information to any online service unless you are comfortable doing so.</p></div></section>'+relatedHtml+'<section class="section"><div class="card"><h2>Frequently asked questions</h2><h3>Is this tool free?</h3><p class="muted">Yes, this Tools Hub utility is available free of charge.</p><h3>Does it require an API key?</h3><p class="muted">No API key is required for this core browser-based utility.</p></div></section></main><footer class="footer"><div class="footerin"><div><b>Tools Hub</b><div>Free utilities · Privacy-first · Mobile & desktop</div></div><a class="btn" href="/tools">Browse tools</a></div></footer><script>if(localStorage.getItem(\"th_dark\")===\"true\")document.documentElement.classList.add(\"dark\");</script>';
 return res.send(page({title:name+' — Free Online '+cat+' Tool | Tools Hub',description:desc+' Free, fast and browser-based on Tools Hub.',canonical:url},body));
}