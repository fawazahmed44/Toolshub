import { storage } from "hatchable";

export const access = "public";
export const methods = ["POST"];

const POLL = "https://gen.pollinations.ai";

function cleanName(s) { return String(s || "output").replace(/[^a-z0-9_-]+/gi, "-").slice(0, 60); }

export default async function (req, res) {
  try {
    const b = req.body || {};
    const type = b.type || "image";
    const prompt = String(b.prompt || "").trim();
    if (!prompt) return res.status(400).json({ ok:false, error:"Enter a prompt." });

    let url, contentType, ext;
    if (type === "image") {
      const p = encodeURIComponent(prompt);
      const qs = new URLSearchParams({ model: b.model || "zimage", width: String(b.width || 1024), height: String(b.height || 1024), seed: String(b.seed || Math.floor(Math.random()*2147483647)), ...(b.safe ? {safe:"true"}:{}) });
      url = `${POLL}/image/${p}?${qs}`; contentType = "image/jpeg"; ext = "jpg";
    } else if (type === "video") {
      const p = encodeURIComponent(prompt);
      const qs = new URLSearchParams({ model: b.model || "wan", duration: String(b.duration || 5), aspectRatio: b.aspectRatio || "16:9", ...(b.audio ? {audio:"true"}:{}), ...(b.seed ? {seed:String(b.seed)}:{}) });
      url = `${POLL}/video/${p}?${qs}`; contentType = "video/mp4"; ext = "mp4";
    } else if (type === "audio") {
      const p = encodeURIComponent(prompt);
      const qs = new URLSearchParams({ voice: b.voice || "nova", ...(b.model ? {model:b.model}: {}) });
      url = `${POLL}/audio/${p}?${qs}`; contentType = "audio/mpeg"; ext = "mp3";
    } else if (type === "chat") {
      const key = b.key || "";
      const headers = {"Content-Type":"application/json"};
      if (key) headers.Authorization = `Bearer ${key}`;
      const r = await fetch(`${POLL}/v1/chat/completions`, {method:"POST", headers, body:JSON.stringify({model:b.model || "openai", messages:b.messages || [{role:"user",content:prompt}]})});
      const data = await r.json();
      if (!r.ok) return res.status(r.status).json({ok:false,error:data?.error?.message || "Chat provider error",raw:data});
      return res.json({ok:true,type:"chat",text:data?.choices?.[0]?.message?.content || "",raw:data});
    } else return res.status(400).json({ok:false,error:"Unsupported generator."});

    const r = await fetch(url, {headers: b.key ? {Authorization:`Bearer ${b.key}`} : {}});
    if (!r.ok) {
      const text = await r.text();
      return res.status(r.status).json({ok:false,error:`Provider returned ${r.status}. ${text.slice(0,300)}`});
    }
    const buf = Buffer.from(await r.arrayBuffer());
    if (!buf.length) return res.status(502).json({ok:false,error:"Provider returned an empty file."});
    const actual = r.headers.get("content-type") || contentType;
    const key = `ai/${Date.now()}-${Math.random().toString(36).slice(2)}-${cleanName(prompt)}.${ext}`;
    const saved = await storage.put(key, buf, actual);
    return res.json({ok:true,type,url:saved,contentType:actual,size:buf.length,prompt,model:b.model || (type === "image" ? "zimage" : type === "video" ? "wan" : "nova")});
  } catch (e) {
    return res.status(500).json({ok:false,error:e?.message || "Generation failed."});
  }
}