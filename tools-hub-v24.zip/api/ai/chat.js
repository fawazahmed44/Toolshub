import { ai } from "hatchable";
export const access = "public";
export default async function(req,res){
 if(req.method!=="POST") return res.status(405).json({error:"POST only"});
 const prompt=String(req.body?.prompt||"").trim(); if(!prompt)return res.status(400).json({error:"Message is required"});
 try{const r=await ai.generateText({model:"sonnet",prompt,maxSteps:1,purpose:"tools-hub-chat"});res.json({text:r?.text||r})}catch(e){res.status(500).json({error:"AI service unavailable"})}
}