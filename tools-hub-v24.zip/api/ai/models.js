export const access = "public";
export const methods = ["GET"];
export default async function(req,res){
  try {
    const [all,img,audio,text] = await Promise.all([
      fetch("https://gen.pollinations.ai/models"), fetch("https://gen.pollinations.ai/image/models"), fetch("https://gen.pollinations.ai/audio/models"), fetch("https://gen.pollinations.ai/text/models")
    ]);
    const json=async r=>r.ok?r.json():[];
    res.json({ok:true,all:await json(all),image:await json(img),audio:await json(audio),text:await json(text)});
  } catch(e){res.status(502).json({ok:false,error:e.message});}
}