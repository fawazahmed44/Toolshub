export const access = "public";

const IMAGE_SPACE = "https://mrfakename-z-image-turbo.hf.space";
const VIDEO_SPACE = "https://r3gm-wan2-2-fp8da-aoti-preview.hf.space";
const WHISPER_SPACE = "https://openai-whisper.hf.space";

async function sseResult(response) {
  const text = await response.text();
  const events = text.split(/\n\n+/);
  for (const event of events) {
    const lines = event.split(/\n/);
    const type = lines.find(x => x.startsWith("event:"))?.slice(6).trim();
    const data = lines.find(x => x.startsWith("data:"))?.slice(5).trim();
    if (type === "complete" && data) return JSON.parse(data);
    if (type === "error" && data) throw new Error(data);
  }
  throw new Error("The AI queue ended without a result.");
}

async function upload(space, file) {
  const form = new FormData();
  form.append("files", new Blob([file.buffer], { type: file.contentType || "application/octet-stream" }), file.filename || "upload");
  const r = await fetch(`${space}/gradio_api/upload`, { method: "POST", body: form });
  if (!r.ok) throw new Error(`AI file upload failed (${r.status}).`);
  const paths = await r.json();
  if (!Array.isArray(paths) || !paths[0]) throw new Error("AI file upload returned no path.");
  return paths[0];
}

function publicUrl(space, value) {
  if (!value) return null;
  if (typeof value === "string") return value.startsWith("http") ? value : `${space}${value}`;
  // Gradio Image/Video outputs are FileData objects. Prefer the public URL
  // returned by Gradio; otherwise use the file route with the raw path.
  return value.url || (value.path ? `${space}/gradio_api/file=${value.path}` : null);
}

async function persistResult(space, value, fallbackType, fallbackName) {
  const remote = publicUrl(space, value);
  if (!remote) throw new Error(`AI service returned no ${fallbackType} file.`);
  const r = await fetch(remote);
  if (!r.ok) throw new Error(`Generated ${fallbackType} could not be retrieved (${r.status}).`);
  const bytes = Buffer.from(await r.arrayBuffer());
  if (!bytes.length) throw new Error(`Generated ${fallbackType} was empty.`);
  const contentType = r.headers.get("content-type") || (fallbackType === "image" ? "image/png" : "video/mp4");
  const ext = contentType.includes("webm") ? "webm" : contentType.includes("jpeg") || contentType.includes("jpg") ? "jpg" : contentType.includes("png") ? "png" : contentType.includes("gif") ? "gif" : contentType.includes("quicktime") ? "mov" : "mp4";
  const key = `ai-results/${Date.now()}-${crypto.randomUUID()}.${ext}`;
  const url = await storage.put(key, bytes, contentType);
  return { url, contentType, size: bytes.length, name: fallbackName || `tools-hub-${fallbackType}.${ext}` };
}

export default async function(req, res) {
  try {
    if (req.method !== "POST") return res.status(405).json({ error: "POST required" });
    const task = req.body?.task;
    if (task === "image") {
      const prompt = String(req.body?.prompt || "").trim();
      if (!prompt) return res.status(400).json({ error: "Enter an image prompt." });
      const payload = {
        prompt,
        height: Math.min(1536, Math.max(512, Number(req.body?.height || 1024))),
        width: Math.min(1536, Math.max(512, Number(req.body?.width || 1024))),
        num_inference_steps: Math.min(12, Math.max(4, Number(req.body?.steps || 9))),
        seed: Number(req.body?.seed || 42),
        randomize_seed: req.body?.randomize !== false
      };
      const r = await fetch(`${IMAGE_SPACE}/gradio_api/call/v2/generate_image`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error(`Image service unavailable (${r.status}).`);
      const ticket = await r.json();
      const result = await sseResult(await fetch(`${IMAGE_SPACE}/gradio_api/call/generate_image/${ticket.event_id}`));
      const saved = await persistResult(IMAGE_SPACE, result?.[0], "image", "tools-hub-generated-image");
      return res.json({ ok: true, type: "image", url: saved.url, downloadUrl: saved.url, contentType: saved.contentType, size: saved.size, name: saved.name, seed: result?.[1] ?? null, provider: "Hugging Face ZeroGPU" });
    }

    if (task === "video") {
      const file = req.files?.find(f => /^image\//.test(f.contentType || ""));
      if (!file) return res.status(400).json({ error: "Upload a starting image for video generation." });
      const path = await upload(VIDEO_SPACE, file);
      const input = {
        input_image: { path, meta: { _type: "gradio.FileData" }, orig_name: file.filename, mime_type: file.contentType },
        last_image: { path, meta: { _type: "gradio.FileData" }, orig_name: file.filename, mime_type: file.contentType },
        prompt: String(req.body?.prompt || "cinematic natural motion"),
        steps: 4,
        negative_prompt: String(req.body?.negative || "blurry, distorted, low quality"),
        duration_seconds: 2,
        guidance_scale: 0,
        guidance_scale_2: 0,
        seed: Number(req.body?.seed || 42),
        randomize_seed: true,
        quality: 4,
        scheduler: "FlowMatchEulerDiscrete",
        flow_shift: 0.5,
        frame_multiplier: "16",
        video_component: true,
        safe_mode: true,
        enable_safety_checker: true
      };
      const r = await fetch(`${VIDEO_SPACE}/run/generate_video`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(input) });
      if (!r.ok) throw new Error(`Video service unavailable (${r.status}).`);
      const data = await r.json();
      const videoValue = data?.video || data?.output?.video || data?.output;
      const saved = await persistResult(VIDEO_SPACE, videoValue, "video", "tools-hub-generated-video");
      return res.json({ ok: true, type: "video", url: saved.url, downloadUrl: saved.url, contentType: saved.contentType, size: saved.size, name: saved.name, provider: "Hugging Face ZeroGPU" });
    }

    if (task === "transcribe") {
      const file = req.files?.[0];
      if (!file) return res.status(400).json({ error: "Upload an audio file." });
      const path = await upload(WHISPER_SPACE, file);
      const payload = { inputs: { path, meta: { _type: "gradio.FileData" }, orig_name: file.filename, mime_type: file.contentType }, task: "transcribe" };
      const r = await fetch(`${WHISPER_SPACE}/gradio_api/call/predict`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ data: [payload.inputs, payload.task] }) });
      if (!r.ok) throw new Error(`Transcription service unavailable (${r.status}).`);
      const ticket = await r.json();
      const result = await sseResult(await fetch(`${WHISPER_SPACE}/gradio_api/call/predict/${ticket.event_id}`));
      return res.json({ ok: true, type: "text", text: result?.[0] || "", provider: "Hugging Face ZeroGPU" });
    }

    return res.status(400).json({ error: "Unknown AI task." });
  } catch (e) {
    return res.status(502).json({ error: e?.message || "Free AI service is temporarily busy. Try again." });
  }
}