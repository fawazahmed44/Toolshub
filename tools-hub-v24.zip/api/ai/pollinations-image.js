export const access = "public";
export const methods = ["POST"];

export default async function (req, res) {
  try {
    const body = req.body || {};
    const prompt = String(body.prompt || "").trim();
    const size = Math.min(1024, Math.max(512, Number(body.size) || 1024));
    if (!prompt) return res.status(400).json({ error: "Enter a prompt first." });
    if (prompt.length > 1200) return res.status(400).json({ error: "Prompt is too long. Keep it under 1200 characters." });

    const safePrompt = prompt.replace(/[\r\n]+/g, " ").trim();
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(safePrompt)}?width=${size}&height=${size}&nologo=true&safe=true`;
    const upstream = await fetch(url);
    const type = upstream.headers.get("content-type") || "";
    if (!upstream.ok || !type.startsWith("image/")) {
      let detail = "The image service did not return an image.";
      try { detail = (await upstream.text()).slice(0, 500) || detail; } catch (_) {}
      return res.status(502).json({ error: detail });
    }

    const bytes = new Uint8Array(await upstream.arrayBuffer());
    if (bytes.byteLength < 1000) return res.status(502).json({ error: "The image service returned an empty image. Please try again." });
    res.setHeader("Content-Type", type);
    res.setHeader("Content-Disposition", 'inline; filename="tools-hub-generated-image.jpg"');
    res.setHeader("Cache-Control", "no-store");
    return res.send(bytes);
  } catch (e) {
    return res.status(500).json({ error: "Image generation failed. Please try again." });
  }
}