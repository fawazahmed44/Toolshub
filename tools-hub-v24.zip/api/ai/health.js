export const access = "public";
export const methods = ["GET"];
export default async function(req,res){
  const providers={
    pollinations:"requires provider key/server configuration",
    hatchable_ai:"requires configured AI provider key",
    local:"available only when a local/runtime engine is connected"
  };
  res.json({ok:true,status:"degraded-safe",providers,generatedAt:new Date().toISOString(),message:"AI provider availability is reported honestly; unavailable providers are never shown as successful generations."});
}