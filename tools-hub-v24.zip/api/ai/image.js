import { ai } from "hatchable";
export const access = "public";
export default async function(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"POST only"});
  const prompt=String(req.body?.prompt||"").trim();
  if(!prompt) return res.status(400).json({error:"Prompt is required"});
  try {
    const r=await ai.generateText({model:"sonnet",prompt:`You are an image-generation prompt optimizer. Return ONLY one detailed production-ready image prompt for this request: ${prompt}`,maxSteps:1,purpose:"image-prompt"});
    res.json({prompt:r?.text||r});
  } catch(e){res.status(500).json({error:"AI service unavailable",detail:String(e?.message||e)})}
}